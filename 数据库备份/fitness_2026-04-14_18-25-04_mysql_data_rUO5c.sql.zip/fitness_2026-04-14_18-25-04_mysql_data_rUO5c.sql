-- MySQL dump 10.13  Distrib 5.7.40, for Linux (x86_64)
--
-- Host: localhost    Database: fitness
-- ------------------------------------------------------
-- Server version	5.7.40-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('56021e42831d');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `checkin_records`
--

DROP TABLE IF EXISTS `checkin_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `checkin_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `checkin_date` date NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `unique_user_checkin` (`user_id`,`checkin_date`),
  CONSTRAINT `checkin_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `checkin_records`
--

LOCK TABLES `checkin_records` WRITE;
/*!40000 ALTER TABLE `checkin_records` DISABLE KEYS */;
INSERT INTO `checkin_records` VALUES (1,1,'2026-03-06','2026-03-06 03:46:03'),(2,2,'2026-03-07','2026-03-07 02:44:43'),(3,1,'2026-03-07','2026-03-07 03:52:51'),(4,4,'2026-03-07','2026-03-07 08:06:39'),(5,1,'2026-03-10','2026-03-10 01:38:26'),(6,5,'2026-03-10','2026-03-10 02:48:56'),(7,1,'2026-03-11','2026-03-11 14:19:22'),(8,1,'2026-03-12','2026-03-12 09:24:21'),(9,6,'2026-03-13','2026-03-13 09:20:15'),(10,1,'2026-03-16','2026-03-15 23:02:16'),(11,1,'2026-03-24','2026-03-24 12:12:03'),(12,8,'2026-03-26','2026-03-26 04:08:40'),(13,1,'2026-03-26','2026-03-26 11:06:31'),(14,1,'2026-03-29','2026-03-29 11:09:36'),(15,9,'2026-03-30','2026-03-30 14:23:52'),(16,1,'2026-04-10','2026-04-10 13:17:30');
/*!40000 ALTER TABLE `checkin_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `diet_records`
--

DROP TABLE IF EXISTS `diet_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diet_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `record_date` date NOT NULL,
  `meal_type` varchar(20) NOT NULL,
  `food_name` varchar(200) NOT NULL,
  `calories` float DEFAULT NULL,
  `notes` text,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `diet_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `diet_records`
--

LOCK TABLES `diet_records` WRITE;
/*!40000 ALTER TABLE `diet_records` DISABLE KEYS */;
INSERT INTO `diet_records` VALUES (1,1,'2026-03-06','lunch','开胃小菜',32,NULL,'2026-03-06 03:43:38'),(2,1,'2026-03-06','lunch','卤鸡腿',180,NULL,'2026-03-06 03:44:23'),(3,1,'2026-03-06','lunch','米饭',200,NULL,'2026-03-06 03:45:12'),(4,1,'2026-03-06','lunch','蛋白粉',120,NULL,'2026-03-06 06:03:05'),(5,1,'2026-03-06','dinner','小炒肉',421,NULL,'2026-03-06 09:59:31'),(6,1,'2026-03-06','dinner','炒白菜',50,NULL,'2026-03-06 10:00:12'),(7,1,'2026-03-06','dinner','米饭',150,NULL,'2026-03-06 10:00:22'),(8,1,'2026-03-07','lunch','午餐',410,NULL,'2026-03-07 03:53:02'),(9,1,'2026-03-07','breakfast','两个鸡蛋',100,NULL,'2026-03-07 03:53:18'),(10,1,'2026-03-08','lunch','午餐',400,NULL,'2026-03-08 10:53:33'),(11,1,'2026-03-08','dinner','晚餐',700,NULL,'2026-03-08 10:53:49'),(12,1,'2026-03-09','breakfast','鸡蛋*2',140,NULL,'2026-03-09 02:59:49'),(14,1,'2026-03-09','lunch','午餐',500,NULL,'2026-03-09 03:51:23'),(15,1,'2026-03-09','dinner','晚餐',700,NULL,'2026-03-09 12:11:37'),(16,1,'2026-03-10','lunch','午饭',500,NULL,'2026-03-10 04:00:18'),(18,1,'2026-03-10','lunch','鸭腿',250,NULL,'2026-03-10 04:01:12'),(19,1,'2026-03-10','dinner','晚餐',700,NULL,'2026-03-10 14:07:10'),(20,1,'2026-03-11','lunch','沙县',600,NULL,'2026-03-11 04:36:34'),(21,1,'2026-03-11','dinner','晚餐',600,NULL,'2026-03-11 10:01:28'),(22,1,'2026-03-11','dinner','蛋白粉',150,NULL,'2026-03-11 14:19:38'),(23,1,'2026-03-12','breakfast','鸡蛋',150,NULL,'2026-03-12 04:09:33'),(24,1,'2026-03-12','lunch','午餐',600,NULL,'2026-03-12 04:09:41'),(25,1,'2026-03-13','breakfast','鸡蛋豆浆',140,NULL,'2026-03-13 02:02:28'),(26,1,'2026-03-13','lunch','午餐',500,NULL,'2026-03-13 03:37:30'),(27,1,'2026-03-15','lunch','午餐',450,NULL,'2026-03-15 03:53:18'),(28,1,'2026-03-16','breakfast','豆浆',80,NULL,'2026-03-15 23:02:53'),(29,1,'2026-03-16','lunch','午餐',500,NULL,'2026-03-16 10:00:35'),(30,1,'2026-03-16','dinner','晚餐',500,NULL,'2026-03-16 10:00:44'),(31,1,'2026-03-16','dinner','菠萝，蛋白粉',350,NULL,'2026-03-16 15:02:55'),(32,1,'2026-03-17','breakfast','馒头',220,NULL,'2026-03-17 02:15:19'),(33,1,'2026-03-17','lunch','午餐',500,NULL,'2026-03-17 09:40:25'),(34,1,'2026-03-17','dinner','晚餐',600,NULL,'2026-03-17 09:40:36'),(35,1,'2026-03-18','lunch','沙县鸡腿饭',700,NULL,'2026-03-18 04:22:30'),(36,1,'2026-03-19','breakfast','豆浆',100,NULL,'2026-03-19 07:19:44'),(37,1,'2026-03-19','lunch','午餐',700,NULL,'2026-03-19 07:20:03'),(38,1,'2026-03-19','dinner','水',150,NULL,'2026-03-19 07:20:15'),(39,1,'2026-03-19','dinner','香蕉',120,NULL,'2026-03-19 07:35:19'),(40,1,'2026-03-19','dinner','蛋白粉',150,NULL,'2026-03-19 07:35:48'),(41,1,'2026-03-19','dinner','鸭腿',200,NULL,'2026-03-19 07:36:08'),(42,1,'2026-03-24','lunch','沙县鸡腿饭',700,NULL,'2026-03-24 12:12:39'),(43,1,'2026-03-24','dinner','蛋白粉，菠萝，鸭腿',450,NULL,'2026-03-24 12:12:59'),(44,1,'2026-03-25','breakfast','馒头豆浆',350,NULL,'2026-03-25 00:27:54'),(45,1,'2026-03-26','breakfast','豆浆馒头',350,NULL,'2026-03-26 11:07:24'),(46,1,'2026-03-26','lunch','鸡腿饭',500,NULL,'2026-03-26 11:07:34'),(47,1,'2026-03-26','dinner','三碗牛肉刀削面',2000,NULL,'2026-03-26 11:08:51'),(48,1,'2026-04-01','breakfast','早餐',300,NULL,'2026-04-01 00:58:45'),(49,1,'2026-04-07','breakfast','鸡蛋2',100,NULL,'2026-04-07 03:37:46'),(50,1,'2026-04-08','breakfast','鸡蛋2',100,NULL,'2026-04-08 01:08:06'),(51,1,'2026-04-08','lunch','沙县',800,NULL,'2026-04-08 13:28:39'),(52,1,'2026-04-08','dinner','菠萝',60,NULL,'2026-04-08 13:29:02'),(53,1,'2026-04-08','dinner','鸭腿',200,NULL,'2026-04-08 13:29:09'),(54,1,'2026-04-10','lunch','番茄炒蛋',86,NULL,'2026-04-10 13:19:49');
/*!40000 ALTER TABLE `diet_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exercise_records`
--

DROP TABLE IF EXISTS `exercise_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exercise_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `record_date` date NOT NULL,
  `calories_burned` float DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `exercise_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise_records`
--

LOCK TABLES `exercise_records` WRITE;
/*!40000 ALTER TABLE `exercise_records` DISABLE KEYS */;
INSERT INTO `exercise_records` VALUES (1,1,'2026-03-06',500,'背','2026-03-06 03:45:40'),(2,1,'2026-03-10',400,'运动','2026-03-10 14:06:59'),(3,1,'2026-03-11',250,'练胸','2026-03-11 14:20:24'),(4,1,'2026-03-16',300,'练背','2026-03-16 15:02:40'),(5,1,'2026-03-17',200,'体育课','2026-03-17 09:40:16'),(6,1,'2026-03-24',400,'体育课加健身','2026-03-24 12:12:27'),(7,1,'2026-03-26',300,'','2026-03-26 11:07:01'),(8,1,'2026-04-08',60,'跑步','2026-04-08 13:29:32'),(9,1,'2026-04-10',250,'无氧运动','2026-04-10 13:17:59');
/*!40000 ALTER TABLE `exercise_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(80) NOT NULL,
  `password_hash` varchar(256) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `email` varchar(120) DEFAULT NULL,
  `height` float DEFAULT NULL,
  `weight_kg` float DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'tyy','scrypt:32768:8:1$tzvMn2E0l0KfwlYu$9d47726c9e27f613a44b2b611ca177e146fc76ef00bd8df11acb801f7b0e3b53db3de6b78845919c622cc99e3deb64069eb2658b9b55b0e680219802008cb021','2026-03-05 16:04:17',NULL,NULL,NULL,NULL,NULL),(2,'aaaammmm','scrypt:32768:8:1$YjjW4whhsI2T3YSo$fe12237f79618392e914be65a499e8583fe69d315f6e97316e87e3e18ab4129838b325bbbd8769b36a6b8129462f02f1e74f5b03139f9f4657c49d240de5ac79','2026-03-05 16:09:13',NULL,NULL,NULL,NULL,NULL),(3,'难逢今宵梦中','scrypt:32768:8:1$TxSB6kyDa9EzTTr7$2ee832b74f7c816ea601a68dcf1714d1b74a17021cd710d55c0a968bac6721e83eae992beb18d199ed04c2f5987b3967cb2c8dc6a6bbab17ff9da8860cca1d4e','2026-03-06 14:35:33','1632850394@qq.com',NULL,NULL,NULL,NULL),(4,'nima','scrypt:32768:8:1$mbUZrvYZ6joamYa4$bf162c403925b8279dae353ae97059576e4af7fa48cde0e5cdc100679759f3bab0e7df7b732bc6ef94d307051a4f655b5aeff08be5fa07a4af5994699a7c1c7e','2026-03-07 08:06:28','1656351159@qq.com',NULL,NULL,NULL,NULL),(5,'IOLO_Miss','scrypt:32768:8:1$kMTup6KRLQid8URk$9ff89799c46401a72e5f76d99599b9403972921d9ff9c74ed3d1cfef93bed81b12d2bcc9afd2540164f0f100437614bed0e286d8903091915de5b775e0d960bb','2026-03-10 02:44:11','2198418245@qq.com',NULL,NULL,NULL,NULL),(6,'Lkplay','scrypt:32768:8:1$W5nK4M7dcuwM2BfE$7d9a9d21ccdba8ed07675c972ab6eb6973eae4eb36a306a17e666831075c81f5b95251b8ec2cf6c7878f601096282a04475f65507d5d80ba27b197321e524739','2026-03-13 09:19:52','1650599452@qq.com',NULL,NULL,NULL,NULL),(7,'xiaomo','scrypt:32768:8:1$wnliwJSge8Ogy9iZ$b7c702ff0619ef1fdbc5bf1de2944141cdd4895029165c71525bf617e655be170bcc598a11e484dd6aa3f8232951caed4b4ef827f67aecef29187a291b5a6687','2026-03-25 09:45:35','2947693868@qq.com',NULL,NULL,NULL,NULL),(8,'奕笙yyds','scrypt:32768:8:1$itePtq5CKgL0bkpO$272adda4bf7ffc46ce74864d2e75644615fd33297cdb0c01c23c3db9036e145b7f87f49035ff645bc67d829cfc78ba635e2fdd05006c594b7aaf990bd79752d3','2026-03-26 04:07:59','750744529@qq.com',NULL,NULL,NULL,NULL),(9,'11111','scrypt:32768:8:1$texGSMmXFrL2cBsH$78001d6a979a4b7c45522255eb01ac344fe8d3f85c01a59ad883ae4352d3875c561062fc7cb19c3dc6355a9f489369a93e40a6cba1461d1c895e041145ba6d92','2026-03-30 09:09:13','2179598757@qq.com',NULL,NULL,NULL,NULL),(10,'朱玥静','scrypt:32768:8:1$jRzcPgNYDNR1CCHb$dce7f188000fdb86a8d0ba0299287f66372496eb828320e2ed514a4635b515aa162f6b25c4e2e0f881ad3c1399f7220ae6c3860d316a3a817c7836c2fe6a8d0c','2026-03-30 15:45:21','3254860773@qq.com',NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `weight_records`
--

DROP TABLE IF EXISTS `weight_records`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weight_records` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `record_date` date NOT NULL,
  `weight` float NOT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `weight_records_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weight_records`
--

LOCK TABLES `weight_records` WRITE;
/*!40000 ALTER TABLE `weight_records` DISABLE KEYS */;
INSERT INTO `weight_records` VALUES (1,1,'2026-03-05',78,'2026-03-06 01:47:28'),(2,1,'2026-03-06',77.3,'2026-03-06 01:48:26'),(3,1,'2026-03-07',77,'2026-03-07 02:08:14'),(4,1,'2026-03-08',77.7,'2026-03-08 03:02:53'),(5,1,'2026-03-09',77,'2026-03-09 02:17:27'),(6,1,'2026-03-10',77,'2026-03-10 01:38:39'),(7,1,'2026-03-11',76.6,'2026-03-11 04:00:44'),(8,1,'2026-03-12',76.4,'2026-03-11 23:29:38'),(9,1,'2026-03-13',77.1,'2026-03-13 01:20:22'),(10,1,'2026-03-14',77.15,'2026-03-14 01:27:42'),(11,1,'2026-03-15',77.5,'2026-03-15 01:41:38'),(12,1,'2026-03-16',77.1,'2026-03-16 00:00:35'),(13,1,'2026-03-18',76.8,'2026-03-18 03:42:02'),(14,1,'2026-03-19',76.5,'2026-03-18 22:57:12'),(15,1,'2026-03-20',75.85,'2026-03-20 02:34:39'),(16,1,'2026-03-23',77.5,'2026-03-22 23:08:46'),(17,1,'2026-03-24',76.1,'2026-03-24 01:20:33'),(18,1,'2026-03-25',75.6,'2026-03-25 00:27:15'),(19,1,'2026-03-26',75.8,'2026-03-26 01:15:06'),(20,1,'2026-03-29',76.8,'2026-03-29 11:09:32'),(21,1,'2026-03-30',76.3,'2026-03-30 08:49:13'),(22,1,'2026-03-31',75.6,'2026-03-31 23:50:11'),(23,1,'2026-04-01',75.6,'2026-03-31 23:50:18'),(24,1,'2026-04-07',77.25,'2026-04-07 03:37:29'),(25,1,'2026-04-08',75.85,'2026-04-08 01:03:13'),(26,1,'2026-04-09',75.4,'2026-04-08 23:33:21'),(27,1,'2026-04-10',75.25,'2026-04-10 00:47:00'),(28,1,'2026-04-12',75.4,'2026-04-11 23:59:36'),(29,1,'2026-04-14',74.1,'2026-04-14 00:56:24');
/*!40000 ALTER TABLE `weight_records` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'fitness'
--

--
-- Dumping routines for database 'fitness'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-04-14 18:25:04
